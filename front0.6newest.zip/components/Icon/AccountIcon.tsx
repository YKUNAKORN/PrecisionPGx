import { CircleUser } from 'lucide-react';

const AccountIcon = () => {
  return (
    <CircleUser className='size-6' />
  );
};

export default AccountIcon;
