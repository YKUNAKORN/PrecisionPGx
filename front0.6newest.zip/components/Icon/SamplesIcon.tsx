import { TestTube } from 'lucide-react';

const SamplesIcon = () => {
  return (
    <TestTube className='size-6'/>
  );
};

export default SamplesIcon;
