import { FileCode } from 'lucide-react';

const RegisterIcon = () => {
  return (
    <FileCode className='size-6'/>
  );
};

export default RegisterIcon;
