import { Search } from 'lucide-react';

const InterpretIcon = () => {
  return (
    <Search className='size-6'/>
  );
};

export default InterpretIcon;
