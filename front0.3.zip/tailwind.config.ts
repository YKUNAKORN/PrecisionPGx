// import type { Config } from "tailwindcss";

// const config: Config = {
//   darkMode: "class",
//   content: [
//     "./app/**/*.{ts,tsx}",
//     "./components/**/*.{ts,tsx}",
//     "./pages/**/*.{ts,tsx}",
//   ],
//   theme: {
//     extend: {
//       borderRadius: {
//         DEFAULT: "var(--radius)",
//       },
//       colors: {
//         background: "var(--background)",
//         foreground: "var(--foreground)",
//         primary: "var(--primary)",
//         "primary-foreground": "var(--primary-foreground)",
//         secondary: "var(--secondary)",
//         "secondary-foreground": "var(--secondary-foreground)",
//         accent: "var(--accent)",
//         "accent-foreground": "var(--accent-foreground)",
//         destructive: "var(--destructive)",
//         border: "var(--border)",
//         input: "var(--input)",
//         ring: "var(--ring)",
//         sidebar: "var(--sidebar)",
//         "sidebar-foreground": "var(--sidebar-foreground)",
//         "sidebar-primary": "var(--sidebar-primary)",
//         "sidebar-primary-foreground": "var(--sidebar-primary-foreground)",
//       },
//     },
//   },
//   plugins: [],
// };

// export default config;
