import { House } from 'lucide-react';

const HomeIcon = () => {
  return (
    <House className='size-6'/>
  );
};

export default HomeIcon;
