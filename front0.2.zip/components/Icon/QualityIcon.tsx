import { Shield } from 'lucide-react';

const QualityIcon = () => {
  return (
    <Shield className='size-6'/>
  );
};

export default QualityIcon;
